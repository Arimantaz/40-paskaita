function addShoppingListEntry() {
    // pasiimame inputo vertę
    const inputElement = document.getElementById("todo-input");
    const shoppingListValue = inputElement.value;
    inputElement.value = "";

    // Tikrinti ar yra vertė įrašyta ir jei ne rodyti kažkokią klaidą
 
    // sukuriame visiškai naują elementą
    const liElement = document.createElement("li"); // <li></li>
    liElement.innerText = shoppingListValue; //<li>shoppingListValue</li>

    // pasiimti elementą į kurio vidų dėsim
    const ulElement = document.getElementById("todo-list");

    // i ul'o vaikų galą pridedamas elementas
    ulElement.appendChild(liElement);
}


const addButton = document.getElementById("todo-button-add");
addButton.onclick = addShoppingListEntry;


// const pEl = document.getElementById("test")
// pEl.innerHTML = "innerHtml innerHtml <b>innerHtml</b>"
// const pEl2 = document.getElementById("test2")
// pEl2.innerText = "<b>innerText</b>"


