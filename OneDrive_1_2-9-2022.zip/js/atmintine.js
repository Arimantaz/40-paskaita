
// console.log(ulElement) // Document Object Model -> DOM


// const ulElement = document.getElementById("todo-list");
// const elementuSarasas = document.getElementsByTagName("a");
// const elementuSarasas = document.getElementsByClassName("container");

// document.getElementById
// document.getElementsByClassName
// document.getElementsByTagName

// const element = document.querySelector("section > label");
// const otherElement = document.querySelector("section .grid");
// const otherElement2 = document.querySelector(".grid");
// const anotherElement = document.querySelector("#todo-button-clear");

// const elementList = document.querySelectorAll("section > *");



